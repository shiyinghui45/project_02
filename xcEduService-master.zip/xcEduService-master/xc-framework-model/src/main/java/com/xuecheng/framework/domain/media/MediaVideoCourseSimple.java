package com.xuecheng.framework.domain.media;

import lombok.Data;
import lombok.ToString;


/**
 * Created by admin on 2018/3/5.
 */
@Data
@ToString
public class MediaVideoCourseSimple {

    //课程id
    private String courseid;
    //章节id
    private String chapter;

}
